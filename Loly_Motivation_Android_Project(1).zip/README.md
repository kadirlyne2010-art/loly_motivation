# Loly Motivation — Android starter project

This is the first runnable Android shell and UI prototype for Loly Motivation.

## Included in this first build
- Arabic RTL home screen
- Fixed-view stylized garden scene (no people, animals, spirits, religious symbols, crosses, or cross-shaped sparkle effects)
- Add daily tasks, choose category/time, mark tasks complete
- Local persistence for tasks, coins, and points using WebView local storage
- Android project wrapper and GitHub Actions workflow to build a debug APK

## Not implemented yet
AlarmManager notifications and sound selection, calendar views, weekly schedule, habit tracker, focus timer, achievements dashboard, backup, seasonal environment transitions, and production-grade garden rendering are future implementation steps. Buttons marked as under construction are placeholders.

## Build APK with GitHub Actions
1. Upload the contents of this folder to a new GitHub repository.
2. Open the repository's Actions tab.
3. Select **Build Loly Motivation APK**.
4. Press **Run workflow**.
5. When the workflow finishes, open its run and download the **Loly-Motivation-APK** artifact.

The generated APK is a debug build for testing, not a Play Store release.
